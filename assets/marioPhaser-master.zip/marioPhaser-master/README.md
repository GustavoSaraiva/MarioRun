# MarioPhaser
A simple test for phaser creating a Super Mario Bros clone.

I create a very simple Super Mario Bros clone using phaser.io, I must to say that I didn’t have any experience with phaser before at the moment when I coded this experiment.
I’ve been using Phaser.io since, it´s a great framework to create games for the browser, mainly focused on mobile, well documented, with a lot of examples, support for shaders, to name a few.

* Live game: http://agar3s.github.io/marioPhaser/

Use the directional arrows and shift to move faster.
