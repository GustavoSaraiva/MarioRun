export default {
    EMPTY: -1,
    FLAG_LEFT: 450
};