<h1 align="center">
    <img src="src/assets/img/mario.png" alt="Remake Mario in PhaserJS" />
</h1>
<h4 align="center">You can read the written tutorial about the implementation on <strong><a href="https://www.webtips.dev/webtips/phaser/remake-mario-in-phaserjs-part1">webtips.dev</a></strong> 🎮</h4>
